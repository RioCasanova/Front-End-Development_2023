

// note that in the future here we're going to make this variable
// into use an envrionment variable so that we can have different values here for the frontend
// and the backend.

export const BASE_URL = 'http://localhost:5000'