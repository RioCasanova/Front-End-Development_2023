# React RESTFul APIs, State, in a Review App.

# Why?

In the Last Exampel