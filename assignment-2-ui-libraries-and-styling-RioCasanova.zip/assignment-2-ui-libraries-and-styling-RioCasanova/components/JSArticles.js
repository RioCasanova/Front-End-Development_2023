import { NEXT_JS_COOL_SITES } from "@/nextjsSiteList";
import { Typography } from "@mui/material";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";

function JSArticles() {
  return (
    <List>
      {NEXT_JS_COOL_SITES.map((site, index) => {
        return (
          <ListItem key={index}>
            <a href={site.url}>
              <Typography color="primary">{site.name}</Typography>
            </a>
          </ListItem>
        );
      })}
    </List>
  );
}

export { JSArticles };
