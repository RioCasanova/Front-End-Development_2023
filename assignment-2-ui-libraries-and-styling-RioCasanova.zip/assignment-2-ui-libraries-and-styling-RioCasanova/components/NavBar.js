import AppBar from "@mui/material/AppBar";
import { Typography } from "@mui/material";
import Box from "@mui/material/Box";
import Home from "@/pages";
import Head from "@mui/material/";

export default function NavBar() {
  return (
    <Box sx={{ display: "flex", m: 2 }}>
      <AppBar component="nav">
        <div className="pad">
          {" "}
          <Typography
            variant="h6"
            component="div"
            sx={{ flexGrow: 1, display: { xs: "none", sm: "block" }, p: 2 }}
          >
            {document.title}
          </Typography>
        </div>
      </AppBar>
    </Box>
  );
}
