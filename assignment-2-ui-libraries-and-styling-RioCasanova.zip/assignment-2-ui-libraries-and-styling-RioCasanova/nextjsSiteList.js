const NEXT_JS_COOL_SITES = [
  {
    name: "Next.js Blog",
    url: "https://nextjs.org/blog"
  },
  {
    name: "Awesome React Components to take a look at",
    url: "https://github.com/brillout/awesome-react-components"
  },
  {
    name: "Building IOS and Android Apps with React",
    url: "https://reactnative.dev/"
  },
  {
    name: "React Conference Talks on Youtube",
    url: "https://www.youtube.com/results?search_query=react+conference+talks"
  }
]

export { NEXT_JS_COOL_SITES }
